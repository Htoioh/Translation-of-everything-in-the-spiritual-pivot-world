require('dotenv').config();
const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const TEXT_MODEL = process.env.MODELSCOPE_TEXT_MODEL || process.env.MODELSCOPE_MODEL || 'Qwen/Qwen3-30B-A3B-Instruct-2507';
const VISION_MODEL = process.env.MODELSCOPE_VISION_MODEL || 'Qwen/Qwen3-VL-8B-Instruct';
const IMAGE_MODEL = process.env.MODELSCOPE_IMAGE_MODEL || 'Qwen/Qwen-Image';
const IMAGE_EDIT_MODEL = process.env.MODELSCOPE_IMAGE_EDIT_MODEL || 'Qwen/Qwen-Image-Edit-2511';
const BASE_URL = (process.env.MODELSCOPE_BASE_URL || 'https://api-inference.modelscope.cn/v1').replace(/\/$/, '');
const API_KEY = process.env.MODELSCOPE_API_KEY;

app.use(express.json({limit:'18mb'}));
app.use(express.static(__dirname));

const WORLD = `你是“天枢界”的现实物转译与视觉设计引擎。
天枢界是与现实地球镜像平行的东方幻想 RPG 世界：现实物可以通过界枢玉牒被转译为天枢界器物。它不是现代科技世界，也不是泛化的仙侠插画世界。
【世界观视觉圣经】
1. 核心感受：像一个真实存在、有人使用、有人维护的东方灵能文明。器物首先是“能被人拿在手里使用的东西”，其次才是奇幻。
2. 能源逻辑：现代电力/电子功能不得直接以霓虹电路、芯片、全息 UI 表现；统一改写成可见但克制的灵能，例如温润的玉石导光、微弱符纹、内蕴光泽、灵息雾、细小流光。
3. 材料逻辑：优先木、竹、陶、纸、布、皮、青铜、铁、银、玉、石、漆等有真实触感的材料；不同材料必须有不同纹理、重量感、磨损和工艺。
4. 造型逻辑：保留现实物最容易辨认的轮廓、比例、按钮/接口/开合关系等“身份锚点”，再用天枢界材料、结构和工艺解释它。不要凭空变成法杖、飞剑、宝珠、巨大法阵。
5. 环境逻辑：背景应该是天枢界真实生活空间，例如木案、石台、书阁、客栈、工坊、山城街巷、庭院、驿站、修炼场等；环境服务于主体，不喧宾夺主。
6. 灵能强度：以“物件原本功能”为核心，只加入能解释功能的灵能效果；避免满屏金光、雷电、巨大符阵。
7. 视觉质感：写实东方幻想、电影级摄影、真实材质、精细工艺、细腻体积光、自然色彩、轻微灵能光效；画面像一张来自真实天枢界的电影剧照，而不是游戏宣传海报。人物皮肤、布料、木石、金属、雨水、尘埃、灯火必须有可触摸的材质层次；不是赛博朋克、不是现代科幻、不是游戏商城图标、不是廉价仙侠海报。
8. 场景生活逻辑：天枢界的人需要吃饭、赶路、交易、修炼、工作、避雨、照明、通讯与休息。场景中的器物与建筑要服务这些真实生活行为，让世界像“已经运行了很多年”。
8. 世界一致性：每一个新物件都必须回答三个问题——它在天枢界由什么材料制成？当地匠人为什么会这样制作？它为什么仍然能完成原物的核心功能？
力量体系：炼气→筑基→灵士→灵师→灵将→灵王→灵尊→灵圣。
界枢玉牒是两界转化媒介，只能转化无生命物体。`;

function cleanJson(text){
  const match = String(text || '').match(/\{[\s\S]*\}/);
  if(!match) throw new Error('模型没有返回 JSON');
  return JSON.parse(match[0]);
}

async function callModel(messages, model=TEXT_MODEL){
  if(!API_KEY) throw new Error('未设置 MODELSCOPE_API_KEY');
  const response = await fetch(`${BASE_URL}/chat/completions`, {
    method:'POST',
    headers:{'Content-Type':'application/json','Authorization':`Bearer ${API_KEY}`},
    body:JSON.stringify({model,messages,temperature:0.55})
  });
  const text = await response.text();
  if(!response.ok) throw new Error(`ModelScope ${response.status}: ${text}`);
  const data = JSON.parse(text);
  return data.choices?.[0]?.message?.content || '';
}

function worldPrompt(extra=''){
  return `${WORLD}\n${extra}`;
}

app.get('/api/status',(req,res)=>res.json({apiKeyConfigured:Boolean(API_KEY),textModel:TEXT_MODEL,visionModel:VISION_MODEL,imageModel:IMAGE_MODEL,imageEditModel:IMAGE_EDIT_MODEL,baseUrl:BASE_URL}));

app.post('/api/translate', async (req,res)=>{
  try{
    const {input,mode='text',depth='deep',language='zh-CN',imageData,sceneFocus='balanced',sceneShot='cinematic'}=req.body;
    const rules = `
你要输出一个“像真实世界中的物品被重新命名”一样自然的结果，而不是堆砌玄幻词。
【命名硬规则】
- 名称通常 2~5 个汉字，优先像真实器物在当地长期使用后形成的俗称或行话：顺口、具体、有功能暗示、有生活感。
- 不要为了显得玄幻而滥用“灵、玄、天、神、仙、玉、圣、尊、古、太初”等字；除非语义确实需要。
- 不要强行四字成语式命名，不要“XX灵玉”“XX神器”“XX玄天”“XX天机”“XX神兵”这类模板化玄幻名。优先“形态/用途 + 生活化称呼”，让名字像铁匠、掌柜、修士会自然说出口的词。
- 名称必须让人一眼能联想到原物的核心功能或形态。
- 品阶只是游戏数据，不要让品阶决定名字。
【内容】
- original 必须尽可能准确地说出原物。
- description 要像游戏图鉴的真人撰写文本：具体、克制、有细节。
- visualDetails 要描述真实可渲染的外观：轮廓、比例、颜色、结构、材质层次、接缝、磨损、纹理、反射、使用痕迹，以及极克制的灵能表现。
- material、craft、lighting 要分别给出材质、工艺和适合生图的光照。
- 如果是图片，绝对不要凭空添加图片里不存在的第二个主体、额外数量、品牌或文字。
输出严格 JSON，不要 Markdown。字段必须包含：
type,name,rank,attribute,energy,source,original,description,material,craft,visualDetails,lighting,visualAnchor。
visualAnchor 是给图像编辑模型用的“身份锁”：必须详细描述原图主体的轮廓、比例、数量、视角、颜色、主要结构和位置，强调这些必须保持。`;

    let messages;
    if(imageData){
      messages=[
        {role:'system',content:[{type:'text',text:worldPrompt(rules)}]},
        {role:'user',content:[
          {type:'image_url',image_url:{url:imageData}},
          {type:'text',text:`请先识别图片中最主要的单一主体，再进行天枢界转译。只保留照片真正可见的信息。用户补充：${input && !input.startsWith('图片：') ? input : '无'}`}
        ]}
      ];
      const content=await callModel(messages,VISION_MODEL);
      const result=cleanJson(content);
      result.imageRecognized=true;
      res.json(result);
    }else if(mode==='scene'){
      const sceneRules=`\n【场景专用规则】\n- 你不是只给场景起一个名字，而是要把场景完整转译为“天枢界的一幕”。\n- 先识别并保留原场景中的人物数量、人物关系、动作、主要物件、空间结构、时间、天气与光线。\n- 再逐层重构：人物衣着与身份、器物材质、建筑与街巷、灵能来源、社会生活痕迹。\n- 场景必须有前景/中景/背景层次，并且每一层都有明确视觉内容。\n- 人物不能凭空变成修仙海报式摆拍；动作与环境要有因果关系。\n- 不要把所有东西都“灵化”，只在功能需要时出现克制灵能。\n- 场景焦点：${sceneFocus}；镜头：${sceneShot}。\n- 输出 JSON 字段必须包含：type,name,rank,attribute,energy,source,original,description,material,craft,visualDetails,lighting,visualAnchor,sceneSubjects,sceneSpace,sceneAtmosphere,sceneComposition。\n- sceneSubjects 描述人物/关键物件及数量；sceneSpace 描述空间结构；sceneAtmosphere 描述时间、天气、色调、声音与生活感；sceneComposition 描述前中后景与镜头。`;
      messages=[{role:'system',content:[{type:'text',text:worldPrompt(rules+sceneRules)}]},{role:'user',content:input}];
      const content=await callModel(messages,TEXT_MODEL);
      const result=cleanJson(content);
      result.scene=true;
      res.json(result);
    }else{
      messages=[{role:'system',content:[{type:'text',text:worldPrompt(rules)}]},{role:'user',content:input}];
      const content=await callModel(messages,TEXT_MODEL);
      res.json(cleanJson(content));
    }
  }catch(e){res.status(500).json({error:e.message});}
});

app.post('/api/generate-image', async (req,res)=>{
  try{
    const {result,imageData=null,sourceMode='text',sceneFocus='balanced',sceneShot='cinematic'}=req.body;
    if(!API_KEY)throw new Error('未设置 MODELSCOPE_API_KEY');
    if(!result)throw new Error('缺少鉴定结果');

    const identity=result.visualAnchor||'保持原主体轮廓、比例、数量、视角、主要结构与颜色。';
    const sceneText=sourceMode==='scene'?`
【场景主体】${result.sceneSubjects||'严格根据输入场景识别，不增加主体'}
【场景空间】${result.sceneSpace||'根据输入建立可信空间'}
【场景气氛】${result.sceneAtmosphere||''}
【场景构图】${result.sceneComposition||''}
【场景焦点】${sceneFocus}；【镜头】${sceneShot}
【场景硬约束】保留人物数量、关系、动作、关键物件数量、空间关系；明确前景/中景/背景；人物不能站桩摆拍；环境必须有真实生活痕迹。`:'';

    const prompt=`${WORLD}
你是天枢界资深概念美术师。目标不是“泛东方幻想”，而是让观者相信这个物件/场景本来就生活在天枢界。
【原物】${result.original||'未知'} 【天枢名】${result.name||'未命名'} 【类型】${result.type||'器物'}
【视觉身份锁】${identity}
【材质】${result.material||'根据现实物功能选择木、竹、陶、纸、布、皮、青铜、铁、银、玉、石、漆等真实材料'}
【工艺】${result.craft||'真实可制作的传统工艺'}
【视觉细节】${result.visualDetails||result.description||''}
【光照】${result.lighting||'自然电影级侧光，柔和体积光'}
${sceneText}
【世界观硬规则】
1. 功能优先：原物的核心用途必须仍然成立。
2. 身份优先：如果有原图，保持轮廓、比例、数量、视角、姿态、主要颜色和关键结构，不把它重绘成另一个物种或类别。
3. 世界优先：使用天枢界真实生活中的材料、工艺、建筑、器具和社会痕迹。奇幻来自灵能机制，不来自堆金光。
4. 灵能克制：只在需要解释功能时出现微弱导光、内蕴光泽、细小符纹、灵息或局部流光。
5. 材质可信：木有纹理，金属有重量与划痕，布有纤维，玉有透光与瑕疵，雨水有湿润反射。
6. 禁止：赛博朋克、现代科幻、芯片、电路、霓虹、机甲、现代HUD、游戏商城图标、巨大法阵、夸张金光、廉价仙侠海报、文字水印。
7. 不出现品牌Logo和可读文字。
8. 画面应像真实存在于天枢界的电影剧照/高品质概念摄影，而不是一张“AI概念图”。
${sourceMode==='image'?'这是图像编辑任务：优先保留原图主体身份，只对材质、环境、世界观进行转译。':''}`;

    const headers={'Authorization':`Bearer ${API_KEY}`,'Content-Type':'application/json','X-ModelScope-Async-Mode':'true'};
    const payload={model:sourceMode==='image'?IMAGE_EDIT_MODEL:IMAGE_MODEL,prompt,size:'1328x1328'};
    if(sourceMode==='image'&&imageData)payload.image_url=[imageData];

    const response=await fetch(`${BASE_URL}/images/generations`,{method:'POST',headers,body:JSON.stringify(payload)});
    const body=await response.text();
    if(!response.ok)throw new Error(`ModelScope ${response.status}: ${body}`);
    const created=JSON.parse(body);
    const taskId=created.task_id;
    if(!taskId)throw new Error('ModelScope 没有返回 task_id');

    // 官方 API-Inference 示例使用 /v1/tasks/{task_id} 轮询。
    for(let i=0;i<84;i++){
      await new Promise(r=>setTimeout(r,5000));
      const rr=await fetch(`${BASE_URL}/tasks/${taskId}`,{headers:{
        'Authorization':`Bearer ${API_KEY}`,
        'Content-Type':'application/json',
        'X-ModelScope-Task-Type':'image_generation'
      }});
      const txt=await rr.text();
      if(!rr.ok)throw new Error(`ModelScope 任务查询 ${rr.status}: ${txt}`);
      const task=JSON.parse(txt);
      if(task.task_status==='SUCCEED'){
        const imageUrl=task.output_images?.[0];
        if(!imageUrl)throw new Error('生成成功但没有图片地址');
        return res.json({imageUrl,taskId,mode:sourceMode});
      }
      if(task.task_status==='FAILED')throw new Error(task.error||task.message||'ModelScope 生图任务失败');
    }
    throw new Error('ModelScope 生图任务超过 7 分钟未完成，请稍后重新渲染。');
  }catch(e){res.status(500).json({error:e.message});}
});

app.post('/api/chat',async(req,res)=>{
  try{
    const {message,context=null}=req.body;
    const system=worldPrompt(`你是天枢界中的沉浸式向导。回答自然、克制，不擅自修改世界观。当前图鉴结果：${JSON.stringify(context||{})}`);
    const answer=await callModel([{role:'system',content:system},{role:'user',content:message}],TEXT_MODEL);
    res.json({answer});
  }catch(e){res.status(500).json({error:e.message});}
});

app.listen(PORT,()=>console.log(`天枢界已启动：http://localhost:${PORT}`));
