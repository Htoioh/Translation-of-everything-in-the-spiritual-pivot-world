# 天枢界 · 综合增强版

本版基于上一版实际代码进行综合重构。

## 本次修复

### 1. 修复“正在细化渲染”无限转圈
上一版前端存在渲染状态处理问题，导致生图时可能卡在“正在细化渲染”。
本版：
- 修复前端渲染状态
- 增加阶段式状态显示
- 增加 7 分钟硬超时
- ModelScope 失败会显示具体原因
- 成功/失败都会恢复按钮
- 不再无限等待

### 2. 场景模式升级
场景会同时保留：
- 人物数量与关系
- 动作
- 关键物件
- 空间结构
- 时间/天气
- 光线
- 气氛
- 前景/中景/背景
- 镜头焦点与镜头类型

结果页增加“场景分镜”区域。

### 3. 世界观强化
视觉提示明确要求：
- 天枢界真实生活逻辑
- 传统材料与工艺
- 克制灵能
- 原物功能优先
- 原图主体身份优先
- 禁止赛博朋克、现代科幻、巨大法阵、满屏金光等跑题视觉

### 4. UI 综合升级
- 更明显的层级与景深
- 渐进式渲染 HUD
- 阶段进度
- 场景分镜卡片
- 更细腻的玻璃/墨色界面
- 按钮微动效
- 图片上传交互
- 移动端适配

## ModelScope
Qwen3-VL 可通过 ModelScope API-Inference 接收 image_url；Qwen-Image-Edit-2511 官方模型页提供了异步 images/generations + task polling 的 API 示例。citeturn0search3turn0search0

## 配置

```env
MODELSCOPE_API_KEY=你的Key
MODELSCOPE_BASE_URL=https://api-inference.modelscope.cn/v1
MODELSCOPE_TEXT_MODEL=Qwen/Qwen3-30B-A3B-Instruct-2507
MODELSCOPE_VISION_MODEL=Qwen/Qwen3-VL-8B-Instruct
MODELSCOPE_IMAGE_MODEL=Qwen/Qwen-Image
MODELSCOPE_IMAGE_EDIT_MODEL=Qwen/Qwen-Image-Edit-2511
PORT=3000
```

## 启动

```bash
npm install
npm start
```

浏览器：

```text
http://localhost:3000
```

如果旧服务器仍在运行，先按 `Ctrl + C`，再重新 `npm start`。
