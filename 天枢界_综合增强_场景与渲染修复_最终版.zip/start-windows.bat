@echo off
echo ========================================
echo   灵枢译界 ModelScope 最终版
echo ========================================
if not exist node_modules (
  echo 正在安装依赖...
  npm install
)
if not exist .env (
  copy .env.example .env >nul
  echo 已创建 .env，请先编辑它填写 MODELSCOPE_API_KEY。
  notepad .env
)
echo 正在启动...
npm start
pause
