const state={mode:'text',currentResult:null,sourceImage:null,rendering:false};
const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
const sleep=ms=>new Promise(r=>setTimeout(r,ms));

function showPage(name){
  document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id==='page-'+name));
  document.querySelectorAll('.nav-item').forEach(n=>n.classList.toggle('active',n.dataset.page===name));
  if(name==='history')renderHistory();
}
function switchMode(mode){
  state.mode=mode;
  document.querySelectorAll('.mode-tab').forEach(x=>x.classList.toggle('active',x.dataset.mode===mode));
  ['text','image','scene'].forEach(x=>$(`${x}Mode`).classList.toggle('hidden',x!==mode));
  $('inputHint').textContent=mode==='image'
    ? '先识别并锁定原物，再进行天枢界材质转化'
    : mode==='scene'
      ? '先理解人物、空间与动作，再重建为天枢界的一幕'
      : '输入一个现实物、物品名称或完整场景';
  const badge=$('modeHintBadge'); if(badge) badge.textContent=mode==='image'?'视觉身份锁':'场景叙事引擎';
}
function fileToDataURL(file){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(file);});}
function getInput(){
  if(state.mode==='text')return $('textInput').value.trim();
  if(state.mode==='scene')return $('sceneInput').value.trim();
  const f=$('imageInput').files[0];return f?`图片：${f.name}`:'';
}
function setProgress(step,detail=''){
  const names=['读取现实','建立身份锁','天枢转译','构建视觉','细化渲染'];
  names.forEach((_,i)=>{
    const el=$(`progressStep${i}`); if(el) el.classList.toggle('active',i===step);
    if(el) el.classList.toggle('done',i<step);
  });
  const bar=$('renderProgressBar'); if(bar) bar.style.width=Math.min(95,Math.max(6,(step+1)*18))+'%';
  const title=$('renderProgressTitle'); if(title) title.textContent=names[step]||'正在处理';
  const desc=$('renderProgressDesc'); if(desc) desc.textContent=detail;
}
async function translate(){
  const input=getInput(),file=state.mode==='image'?$('imageInput').files[0]:null;
  if(!input){alert('请先输入内容或上传图片。');return;}
  const btn=$('translateBtn');btn.disabled=true;
  btn.innerHTML='<span class="spin">◌</span> 正在进入天枢界…';
  $('resultBadge').textContent='PROCESSING';
  try{
    const body={input,mode:state.mode,depth:$('depth').value,language:$('language').value};
    if(state.mode==='scene'){body.sceneFocus=$('sceneFocus').value;body.sceneShot=$('sceneShot').value;}
    if(file){body.imageData=await fileToDataURL(file);state.sourceImage=body.imageData;}
    const r=await fetch('/api/translate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    const payload=await r.json().catch(()=>({}));
    if(!r.ok)throw new Error(payload.error||JSON.stringify(payload)||`HTTP ${r.status}`);
    state.currentResult=payload;renderResult(payload);$('resultBadge').textContent='AI 鉴定完成';
    // 场景/图片自动渲染；文字也自动渲染，让输出始终是“文字 + 图像”
    await generateImage({auto:true,imageData:body.imageData||null});
  }catch(e){
    console.error(e);$('resultBadge').textContent='连接异常';
    alert('天枢界 AI 调用失败：\n\n'+e.message);
  }finally{
    btn.disabled=false;btn.innerHTML='<span>✦</span> 开始天枢化';
  }
}
function renderResult(r){
  $('emptyResult').classList.add('hidden');$('resultContent').classList.remove('hidden');
  $('resultType').textContent=r.type||'世界化结果';$('resultName').textContent=r.name||'未命名';$('resultRank').textContent=r.rank||'待鉴定';
  $('originalName').textContent=r.original||'未知';$('resultAttribute').textContent=r.attribute||'未知';$('resultEnergy').textContent=r.energy||'未知';$('resultSource').textContent=r.source||'未知';$('resultDescription').textContent=r.description||'';
  $('materialValue').textContent=r.material||'—';$('craftValue').textContent=r.craft||'—';$('visualValue').textContent=r.visualDetails||'—';$('lightValue').textContent=r.lighting||'—';
  $('flowOriginal').textContent=r.original||'现实物';$('flowResult').textContent=r.name||'未命名';$('anchorValue').textContent=r.visualAnchor||'图像身份锁将在识别后生成。';
  const sceneBox=$('sceneBreakdown'); if(sceneBox){
    const hasScene=Boolean(r.scene||r.sceneSubjects||r.sceneSpace||r.sceneAtmosphere);
    sceneBox.classList.toggle('hidden',!hasScene);
    if(hasScene){
      $('sceneSubjectsValue').textContent=r.sceneSubjects||'—';
      $('sceneSpaceValue').textContent=r.sceneSpace||'—';
      $('sceneAtmosphereValue').textContent=r.sceneAtmosphere||'—';
      $('sceneCompositionValue').textContent=r.sceneComposition||'—';
    }
  }
}
function resultText(){
  const r=state.currentResult;if(!r)return '';
  return `【${r.name}】\n原物：${r.original}\n类型：${r.type}\n品阶：${r.rank}\n属性：${r.attribute}\n能源：${r.energy}\n来源：${r.source}\n材质：${r.material}\n工艺：${r.craft}\n\n${r.description}`;
}
async function generateImage({auto=false,imageData=null}={}){
  const r=state.currentResult;if(!r||state.rendering)return;
  state.rendering=true;
  const btn=$('generateImageBtn'),status=$('imageGenStatus'),wrap=$('generatedImageWrap'),progress=$('renderProgress');
  const sourceMode=imageData?'image':(state.mode==='scene'?'scene':'text');
  const detail=sourceMode==='scene'
    ? '正在锁定人物数量、动作、空间层次与生活痕迹。'
    : sourceMode==='image'
      ? '正在锁定原图轮廓、比例、结构、数量与主要颜色。'
      : '正在把现实物的功能转译成天枢界真实可制作的器物。';
  btn.disabled=true;btn.innerHTML='<span class="spin">◌</span> 渲染中…';
  status.classList.remove('hidden');progress.classList.remove('hidden');wrap.classList.remove('has-image');wrap.classList.add('rendering');
  setProgress(0,detail);
  $('renderModeLabel').textContent=sourceMode==='scene'?'SCENE → TIANSHU':sourceMode==='image'?'IMAGE → TIANSHU':'TEXT → TIANSHU';
  try{
    if(!imageData&&state.mode==='image'&&$('imageInput').files[0])imageData=await fileToDataURL($('imageInput').files[0]);
    const payload={result:r,imageData:imageData||null,sourceMode,sceneFocus:state.mode==='scene'?$('sceneFocus').value:null,sceneShot:state.mode==='scene'?$('sceneShot').value:null};
    const request=fetch('/api/generate-image',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    // UI 进度是“阶段状态”，不是伪造 API 百分比；超过 7 分钟由后端/前端共同终止。
    const phases=[
      [1200,0,'已读取设定，开始建立视觉约束。'],
      [4200,1,detail],
      [9000,2,'正在构建天枢界材质、工艺与环境。'],
      [18000,3,'图像模型正在绘制主体与空间关系。'],
      [35000,4,'正在细化材质、边缘、光线与灵能细节。']
    ];
    phases.forEach(([ms,step,text])=>setTimeout(()=>{if(state.rendering)setProgress(step,text);},ms));
    const timeout=new Promise((_,rej)=>setTimeout(()=>rej(new Error('生图任务超过 7 分钟仍未完成。ModelScope 当前可能繁忙，请稍后点击“重新渲染”。')),420000));
    const rr=await Promise.race([request,timeout]);
    const data=await rr.json().catch(()=>({}));
    if(!rr.ok)throw new Error(data.error||JSON.stringify(data)||`HTTP ${rr.status}`);
    if(!data.imageUrl)throw new Error('ModelScope 返回成功，但没有图片地址。');
    $('generatedImage').src=data.imageUrl;$('generatedImageLink').href=data.imageUrl;
    wrap.classList.remove('hidden','rendering');wrap.classList.add('has-image');progress.classList.add('hidden');
    status.textContent=sourceMode==='scene'?'场景渲染完成 · 人物、空间、动作关系已纳入约束。':sourceMode==='image'?'渲染完成 · 已优先保持原物身份与结构。':'渲染完成 · 已按天枢界材料与生活逻辑构建。';
    $('resultBadge').textContent='视觉完成';
  }catch(e){
    progress.classList.add('hidden');wrap.classList.remove('rendering');
    status.textContent='渲染失败：'+e.message;
    if(!auto)alert('生图失败：\n\n'+e.message);
    else console.error(e);
  }finally{
    state.rendering=false;btn.disabled=false;btn.innerHTML='<span>✦</span> 重新渲染';
  }
}
function saveHistory(){
  if(!state.currentResult)return;
  const a=JSON.parse(localStorage.getItem('tian_history')||'[]');
  a.unshift({...state.currentResult,time:new Date().toLocaleString('zh-CN')});
  localStorage.setItem('tian_history',JSON.stringify(a.slice(0,30)));renderHistory();
}
function renderHistory(){
  const a=JSON.parse(localStorage.getItem('tian_history')||'[]');
  $('historyList').innerHTML=a.length?a.map((r,i)=>`<div class="history-item"><div><strong>${esc(r.original)} → ${esc(r.name)}</strong><span>${esc(r.time)} · 天枢界</span></div><button data-history="${i}">查看</button></div>`).join(''):`<div class="empty-result panel"><div><div class="empty-rune">◌</div><h3>还没有记录</h3><p>完成一次天枢化后，结果会出现在这里。</p></div></div>`;
  document.querySelectorAll('[data-history]').forEach(b=>b.onclick=()=>{state.currentResult=a[+b.dataset.history];showPage('translate');renderResult(state.currentResult);});
}
async function sendChat(){
  const m=$('chatInput').value.trim();if(!m)return;addChat('user',m);$('chatInput').value='';
  try{const r=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:m,context:state.currentResult})});const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||'请求失败');addChat('ai',d.answer||'');}
  catch(e){addChat('ai','暂时无法连接天枢界向导：'+e.message);}
}
function addChat(role,text){
  const d=document.createElement('div');d.className='chat-msg '+role;
  d.innerHTML=role==='ai'?`<div class="avatar">✦</div><div><strong>天枢向导</strong><p>${esc(text)}</p></div>`:`<div class="avatar">你</div><div><strong>你</strong><p>${esc(text)}</p></div>`;
  $('chatMessages').appendChild(d);$('chatMessages').scrollTop=$('chatMessages').scrollHeight;
}
document.querySelectorAll('.nav-item').forEach(n=>n.onclick=()=>showPage(n.dataset.page));
document.querySelectorAll('.mode-tab').forEach(t=>t.onclick=()=>switchMode(t.dataset.mode));
document.querySelectorAll('[data-fill]').forEach(b=>b.onclick=()=>{$('textInput').value=b.dataset.fill;switchMode('text');});
$('translateBtn').onclick=translate;
$('generateImageBtn').onclick=()=>generateImage();
$('saveResult').onclick=saveHistory;
$('copyResult').onclick=async()=>{await navigator.clipboard.writeText(resultText());$('copyResult').textContent='已复制';setTimeout(()=>$('copyResult').textContent='复制结果',1200);};
$('askAi').onclick=()=>{$('chatInput').focus();$('chatInput').value=`请从天枢界的角度解释「${state.currentResult?.name||'这个物件'}」。`;};
$('chatSend').onclick=sendChat;$('chatInput').onkeydown=e=>{if(e.key==='Enter')sendChat();};
$('settingsBtn').onclick=()=>{$('settingsModal').classList.remove('hidden');};
$('modalClose').onclick=()=>{$('settingsModal').classList.add('hidden');};
$('saveSettings').onclick=()=>{$('settingsModal').classList.add('hidden');};
$('imageInput').onchange=async()=>{
  const f=$('imageInput').files[0];if(!f)return;
  if(f.size>12*1024*1024){alert('图片太大，请选择 12MB 以内的图片。');$('imageInput').value='';return;}
  state.sourceImage=await fileToDataURL(f);$('previewImage').src=state.sourceImage;$('dropzone').classList.add('has-image');$('imageMeta').textContent=`已载入 · ${Math.round(f.size/1024)} KB · 将优先保持主体结构`;
};
['sceneFocus','sceneShot'].forEach(id=>$(id)?.addEventListener('change',()=>{const t=$('sceneTuning');if(t)t.textContent=`${$('sceneFocus').selectedOptions[0].text} · ${$('sceneShot').selectedOptions[0].text}`;}));
setInterval(()=>{$('clock').textContent=new Date().toLocaleTimeString('zh-CN',{hour12:false});},1000);
$('clock').textContent=new Date().toLocaleTimeString('zh-CN',{hour12:false});
switchMode('text');renderHistory();
